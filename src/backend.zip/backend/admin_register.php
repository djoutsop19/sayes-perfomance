<?php
header('Content-Type: application/json');
require 'config.php';

$data = json_decode(file_get_contents("php://input"), true);

$fullname = trim($data['fullname'] ?? '');
$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');

if (!$fullname || !$email || !$password) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Tous les champs sont obligatoires."]);
    exit;
}

// Vérifier si l'email ou le fullname existe déjà
$stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ? OR fullname = ?");
$stmt->execute([$email, $fullname]);
if ($stmt->fetch()) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "L'email ou le nom est déjà utilisé."]);
    exit;
}

// Hacher le mot de passe
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insérer l'admin
$stmt = $pdo->prepare(
    "INSERT INTO admins (fullname, email, password) 
     VALUES (?, ?, ?)"
);
$stmt->execute([$fullname, $email, $hashed_password]);

echo json_encode(["success" => true, "message" => "Compte administrateur créé avec succès."]);
?>