<?php
header('Content-Type: application/json');
require 'config.php';
session_start();

$data = json_decode(file_get_contents("php://input"), true);

$fullname = trim($data['fullname'] ?? '');
$email = trim($data['email'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !$fullname) {
    echo json_encode(["success" => false, "message" => "Données invalides."]);
    exit;
}

// Vérifier si l'email existe déjà
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->rowCount() > 0) {
    echo json_encode(["success" => false, "message" => "Email déjà utilisé."]);
    exit;
}

// Générer un mot de passe temporaire
$tempPassword = bin2hex(random_bytes(8)); // Génère une chaîne aléatoire de 16 caractères
$hashedPassword = password_hash($tempPassword, PASSWORD_DEFAULT);

// Insérer l'utilisateur avec verified = 1 et verification_code = 'google'
$stmt = $pdo->prepare("INSERT INTO users (fullname, email, password, verified, verification_code) VALUES (?, ?, ?, 1, 'google')");
$stmt->execute([$fullname, $email, $hashedPassword]);

// Stocker les informations dans la session
$_SESSION['user'] = [
    'id' => $pdo->lastInsertId(),
    'fullname' => $fullname,
    'email' => $email,
    'needs_password_update' => true // Indique que l'utilisateur doit définir un mot de passe
];

echo json_encode([
    "success" => true,
    "message" => "Inscription Google réussie. Veuillez définir un mot de passe.",
    "user" => $_SESSION['user'],
    "temp_password" => $tempPassword // Envoyer le mot de passe temporaire pour information
]);
?>