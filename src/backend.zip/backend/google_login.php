<?php
header('Content-Type: application/json');
require 'config.php';
session_start();

$data = json_decode(file_get_contents("php://input"), true);

$email = trim($data['email'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["success" => false, "message" => "Email invalide."]);
    exit;
}

// Vérifier si l'utilisateur existe
$stmt = $pdo->prepare("SELECT id, fullname, email, verified FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(["success" => false, "message" => "Utilisateur non trouvé. Veuillez vous inscrire."]);
    exit;
}

if (!$user['verified']) {
    echo json_encode(["success" => false, "message" => "Votre compte n'est pas vérifié."]);
    exit;
}

// Stocker les informations dans la session
$_SESSION['user'] = [
    'id' => $user['id'],
    'fullname' => $user['fullname'],
    'email' => $user['email']
];

echo json_encode(["success" => true, "message" => "Connexion Google réussie.", "user" => $_SESSION['user']]);
?>