<?php
header('Content-Type: application/json');
require 'config.php';
session_start();

// Activer les logs pour débogage
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log'); // Assure-toi que ce chemin est correct pour ton serveur

$method = $_SERVER['REQUEST_METHOD'];

error_log("Requête reçue: $method");

switch ($method) {
    case 'POST':
        error_log("POST request received");
        $data = json_decode(file_get_contents("php://input"), true);
        error_log("Données POST reçues: " . json_encode($data));

        $membership_required = isset($data['membership_required']) ? (int)$data['membership_required'] : 0;
        $package_name = trim($data['package_name'] ?? '');
        $frequency = trim($data['frequency'] ?? '');
        $price_per_month = isset($data['price_per_month']) ? (float)$data['price_per_month'] : 0;
        $binding_time = trim($data['binding_time'] ?? '');
        $category = trim($data['category'] ?? '');

        if (!$package_name || !$frequency || !$price_per_month || !$category) {
            error_log("POST failed: Champs obligatoires manquants");
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Tous les champs obligatoires doivent être remplis."]);
            exit;
        }

        if (!in_array($category, ['Group Training', 'Private', 'Summer Camp'])) {
            error_log("POST failed: Catégorie invalide - $category");
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Catégorie invalide."]);
            exit;
        }

        try {
            $stmt = $pdo->prepare(
                "INSERT INTO packages (membership_required, package_name, frequency, price_per_month, binding_time, category) 
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([$membership_required, $package_name, $frequency, $price_per_month, $binding_time, $category]);
            error_log("POST succeeded: Package ajouté");
            echo json_encode(["success" => true, "message" => "Package ajouté avec succès."]);
        } catch (PDOException $e) {
            error_log("POST failed: Erreur PDO - " . $e->getMessage());
            http_response_code(500);
            echo json_encode(["success" => false, "message" => "Erreur serveur: " . $e->getMessage()]);
        }
        break;

    case 'GET':
        error_log("GET request received");
        if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
            error_log("GET failed: Non authentifié");
            http_response_code(401);
            echo json_encode(["success" => false, "message" => "Non authentifié. Veuillez vous connecter."]);
            exit;
        }

        $category = isset($_GET['category']) ? trim($_GET['category']) : null;
        error_log("GET category: " . ($category ?? 'none'));

        try {
            if ($category) {
                if (!in_array($category, ['Group Training', 'Private', 'Summer Camp'])) {
                    error_log("GET failed: Catégorie invalide - $category");
                    http_response_code(400);
                    echo json_encode(["success" => false, "message" => "Catégorie invalide."]);
                    exit;
                }
                $stmt = $pdo->prepare("SELECT * FROM packages WHERE category = ? ORDER BY created_at DESC");
                $stmt->execute([$category]);
            } else {
                $stmt = $pdo->prepare("SELECT * FROM packages ORDER BY created_at DESC");
                $stmt->execute();
            }

            $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("GET succeeded: " . count($packages) . " packages récupérés");
            echo json_encode(["success" => true, "packages" => $packages]);
        } catch (PDOException $e) {
            error_log("GET failed: Erreur PDO - " . $e->getMessage());
            http_response_code(500);
            echo json_encode(["success" => false, "message" => "Erreur serveur: " . $e->getMessage()]);
        }
        break;

    case 'PUT':
        error_log("PUT request received");
        if (!isset($_SESSION['admin'])) {
            error_log("PUT failed: No admin session");
            http_response_code(403);
            echo json_encode(["success" => false, "message" => "Accès non autorisé. Administrateur requis."]);
            exit;
        }

        $data = json_decode(file_get_contents("php://input"), true);
        error_log("Données PUT reçues: " . json_encode($data));
        $id = isset($data['id']) ? (int)$data['id'] : 0;

        if (!$id) {
            error_log("PUT failed: ID du package requis");
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "ID du package requis."]);
            exit;
        }

        $membership_required = isset($data['membership_required']) ? (int)$data['membership_required'] : 0;
        $package_name = trim($data['package_name'] ?? '');
        $frequency = trim($data['frequency'] ?? '');
        $price_per_month = isset($data['price_per_month']) ? (float)$data['price_per_month'] : 0;
        $binding_time = trim($data['binding_time'] ?? '');
        $category = trim($data['category'] ?? '');

        if (!$package_name || !$frequency || !$price_per_month || !$category) {
            error_log("PUT failed: Champs obligatoires manquants");
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Tous les champs obligatoires doivent être remplis."]);
            exit;
        }

        if (!in_array($category, ['Group Training', 'Private', 'Summer Camp'])) {
            error_log("PUT failed: Catégorie invalide - $category");
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Catégorie invalide."]);
            exit;
        }

        try {
            $stmt = $pdo->prepare("SELECT id FROM packages WHERE id = ?");
            $stmt->execute([$id]);
            if (!$stmt->fetch()) {
                error_log("PUT failed: Package ID $id not found");
                http_response_code(404);
                echo json_encode(["success" => false, "message" => "Package non trouvé."]);
                exit;
            }

            $stmt = $pdo->prepare(
                "UPDATE packages SET membership_required = ?, package_name = ?, frequency = ?, price_per_month = ?, binding_time = ?, category = ? WHERE id = ?"
            );
            $stmt->execute([$membership_required, $package_name, $frequency, $price_per_month, $binding_time, $category, $id]);
            error_log("PUT succeeded: Package ID $id modifié");
            echo json_encode(["success" => true, "message" => "Package modifié avec succès."]);
        } catch (PDOException $e) {
            error_log("PUT failed: Erreur PDO - " . $e->getMessage());
            http_response_code(500);
            echo json_encode(["success" => false, "message" => "Erreur serveur: " . $e->getMessage()]);
        }
        break;

    case 'DELETE':
        error_log("DELETE request received");
        error_log("Session admin: " . json_encode($_SESSION['admin'] ?? 'none'));
        if (!isset($_SESSION['admin'])) {
            error_log("DELETE failed: No admin session");
            http_response_code(403);
            echo json_encode(["success" => false, "message" => "Accès non autorisé. Administrateur requis."]);
            exit;
        }

        $data = json_decode(file_get_contents("php://input"), true);
        error_log("Données DELETE reçues: " . json_encode($data));
        $id = isset($data['id']) ? (int)$data['id'] : 0;

        if (!$id) {
            error_log("DELETE failed: ID du package requis");
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "ID du package requis."]);
            exit;
        }

        try {
            $stmt = $pdo->prepare("SELECT id FROM packages WHERE id = ?");
            $stmt->execute([$id]);
            if (!$stmt->fetch()) {
                error_log("DELETE failed: Package ID $id not found");
                http_response_code(404);
                echo json_encode(["success" => false, "message" => "Package non trouvé."]);
                exit;
            }

            // Vérification optionnelle des contraintes (commente si pas de table bookings)
            /*
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE package_id = ?");
            $stmt->execute([$id]);
            if ($stmt->fetchColumn() > 0) {
                error_log("DELETE failed: Package ID $id est utilisé dans des réservations");
                http_response_code(400);
                echo json_encode(["success" => false, "message" => "Impossible de supprimer: package utilisé dans des réservations."]);
                exit;
            }
            */

            $pdo->beginTransaction();
            $stmt = $pdo->prepare("DELETE FROM packages WHERE id = ?");
            $stmt->execute([$id]);
            $pdo->commit();
            error_log("DELETE succeeded: Package ID $id deleted");
            echo json_encode(["success" => true, "message" => "Package supprimé avec succès.", "id" => $id]);
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("DELETE failed: Erreur PDO - " . $e->getMessage());
            http_response_code(500);
            echo json_encode(["success" => false, "message" => "Erreur serveur: " . $e->getMessage()]);
        }
        break;

    default:
        error_log("Méthode non autorisée: $method");
        http_response_code(405);
        echo json_encode(["success" => false, "message" => "Méthode non autorisée."]);
        break;
}
?>