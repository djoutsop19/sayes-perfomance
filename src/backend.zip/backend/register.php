<?php
header('Content-Type: application/json');
require 'config.php';

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $fullname = $input['fullname'] ?? '';
    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Email invalide");
    }

    // Vérifier si email déjà inscrit
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->rowCount() > 0) {
        throw new Exception("Email déjà utilisé");
    }

    // Générer code de vérification à 6 chiffres
    $verification_code = random_int(100000, 999999);
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Stocker temporairement les données dans une table temporaire
    $stmt = $pdo->prepare("INSERT INTO temp_users (fullname, email, password, verification_code) VALUES (?, ?, ?, ?)");
    $stmt->execute([$fullname, $email, $password_hash, $verification_code]);

    // Envoyer mail de vérification
    $subject = "Code de vérification Sayes Performance";
    $message = "Bonjour $fullname,\n\nVotre code de vérification est : $verification_code\n\nMerci.";
    $headers = "From: no-reply@sayesperformance.com";

    if (!mail($email, $subject, $message, $headers)) {
        throw new Exception("Erreur lors de l'envoi de l'email");
    }

    echo json_encode(["success" => true, "message" => "Code de vérification envoyé à votre email.", "email" => $email]);

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>