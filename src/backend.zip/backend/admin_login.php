<?php
header('Content-Type: application/json');
require 'config.php';
session_start();

$data = json_decode(file_get_contents("php://input"), true);

$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');

if (!$email || !$password) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Email et mot de passe sont obligatoires."]);
    exit;
}

// Vérifier si l'admin existe
$stmt = $pdo->prepare("SELECT id, fullname, email, password FROM admins WHERE email = ?");
$stmt->execute([$email]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin || !password_verify($password, $admin['password'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Email ou mot de passe incorrect."]);
    exit;
}

// Créer une session
$_SESSION['admin'] = [
    'id' => $admin['id'],
    'fullname' => $admin['fullname'],
    'email' => $admin['email']
];

echo json_encode(["success" => true, "message" => "Connexion administrateur réussie.", "admin" => $_SESSION['admin']]);
?>