<?php
header('Content-Type: application/json');
require 'config.php';
session_start();

if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Non authentifié. Veuillez vous connecter."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$phone = trim($data['phone'] ?? '');
$username = trim($data['username'] ?? $_SESSION['user']['fullname']); // Conserver l'existant si non fourni
$age = isset($data['age']) ? (int)$data['age'] : null;
$team = trim($data['team'] ?? '');
$country = trim($data['country'] ?? '');
$player_position = trim($data['player_position'] ?? '');
$district = trim($data['district'] ?? '');
$avatar = $data['avatar'] ?? null; // Base64 de l'image

// Vérifier si le username (fullname) est unique (s'il change)
if ($username !== $_SESSION['user']['fullname']) {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE fullname = ? AND id != ?");
    $stmt->execute([$username, $_SESSION['user']['id']]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(["success" => false, "message" => "Ce nom d'utilisateur est déjà utilisé."]);
        exit;
    }
}

// Mettre à jour le profil
$stmt = $pdo->prepare(
    "UPDATE users SET 
        phone = ?, 
        fullname = ?, 
        age = ?, 
        team = ?, 
        country = ?, 
        player_position = ?, 
        district = ?, 
        avatar = ? 
    WHERE id = ?"
);
$stmt->execute([
    $phone ?: null,
    $username,
    $age,
    $team ?: null,
    $country ?: null,
    $player_position ?: null,
    $district ?: null,
    $avatar ?: null,
    $_SESSION['user']['id']
]);

// Mettre à jour la session
$_SESSION['user']['fullname'] = $username;

echo json_encode(["success" => true, "message" => "Profil mis à jour avec succès."]);
?>